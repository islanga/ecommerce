<?php /* Smarty version 3.1.28-dev/63, created on 2015-11-04 21:59:19
         compiled from "C:\wamp\www\tshirtshop\presentation\templates\blank.tpl" */ ?>
<?php
$_valid = $_smarty_tpl->decodeProperties(array (
  'has_nocache_code' => false,
  'version' => '3.1.28-dev/63',
  'unifunc' => 'content_563a71a7b02ff1_82110927',
  'file_dependency' => 
  array (
    '9b5934e6e36fb6b6b919bffc1d3fdff2ad4fca08' => 
    array (
      0 => 'C:\\wamp\\www\\tshirtshop\\presentation\\templates\\blank.tpl',
      1 => 1446667448,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false);
if ($_valid && !is_callable('content_563a71a7b02ff1_82110927')) {
function content_563a71a7b02ff1_82110927 ($_smarty_tpl) {
}
}
