<?php /* Smarty version 3.1.28-dev/63, created on 2015-11-10 18:55:15
         compiled from "C:\wamp\www\tshirtshop\presentation\templates\department.tpl" */ ?>
<?php
$_valid = $_smarty_tpl->decodeProperties(array (
  'has_nocache_code' => false,
  'version' => '3.1.28-dev/63',
  'unifunc' => 'content_56422f88e55c18_80367499',
  'file_dependency' => 
  array (
    'ea9c9e56e11c05193024291f0da11b2346fffe16' => 
    array (
      0 => 'C:\\wamp\\www\\tshirtshop\\presentation\\templates\\department.tpl',
      1 => 1447178111,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false);
if ($_valid && !is_callable('content_56422f88e55c18_80367499')) {
function content_56422f88e55c18_80367499 ($_smarty_tpl) {
if (!is_callable('smarty_function_load_presentation_object')) require_once 'C:\\wamp\\www\\tshirtshop\\presentation\\smarty_plugins\\function.load_presentation_object.php';
?>

<?php echo smarty_function_load_presentation_object(array('filename'=>"department",'assign'=>"obj"),$_smarty_tpl);?>

<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['obj']->value->mName;?>
</h1>
<p class="description"><?php echo $_smarty_tpl->tpl_vars['obj']->value->mDescription;?>
</p>
<?php }
}
