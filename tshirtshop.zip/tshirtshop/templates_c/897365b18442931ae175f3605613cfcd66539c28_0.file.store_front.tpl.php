<?php /* Smarty version 3.1.28-dev/63, created on 2015-12-20 23:12:33
         compiled from "C:\wamp\www\tshirtshop\presentation\templates\store_front.tpl" */ ?>
<?php
$_valid = $_smarty_tpl->decodeProperties(array (
  'has_nocache_code' => false,
  'version' => '3.1.28-dev/63',
  'unifunc' => 'content_567727d81eb8b6_98987393',
  'file_dependency' => 
  array (
    '897365b18442931ae175f3605613cfcd66539c28' => 
    array (
      0 => 'C:\\wamp\\www\\tshirtshop\\presentation\\templates\\store_front.tpl',
      1 => 1450649437,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../../presentation/templates/search_box.tpl' => 1,
    'file:../../presentation/templates/departments_list.tpl' => 1,
  ),
),false);
if ($_valid && !is_callable('content_567727d81eb8b6_98987393')) {
function content_567727d81eb8b6_98987393 ($_smarty_tpl) {
if (!is_callable('smarty_function_load_presentation_object')) require_once 'C:\\wamp\\www\\tshirtshop\\presentation\\smarty_plugins\\function.load_presentation_object.php';
?>

<?php  $_smarty_tpl->configLoad("../../include/configs/site.conf", null, 'local');
echo smarty_function_load_presentation_object(array('filename'=>"store_front",'assign'=>"obj"),$_smarty_tpl);?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
	<head>
		<title><?php echo $_smarty_tpl->tpl_vars['obj']->value->mPageTitle;?>
</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['obj']->value->mSiteUrl;?>
styles/tshirtshop.css" />
	</head>
	<body>
		<div id="doc" class="yui-t2">
			<div id="bd">
				<div id="yui-main">
					<div class="yui-b">
						<div id="header" class="yui-g">
							<a href="<?php echo $_smarty_tpl->tpl_vars['obj']->value->mSiteUrl;?>
">
								<img src="<?php echo $_smarty_tpl->tpl_vars['obj']->value->mSiteUrl;?>
images/tshirtshop.jpg" height="100px" alt="tshirtshop logo" />
							</a>
						</div>
						<div id="contents" class="yui-g">
							<?php $_smarty_tpl->setupSubTemplate($_smarty_tpl->tpl_vars['obj']->value->mContentsCell, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true)->render();
?>

						</div>
					</div>
				</div>
				<div class="yui-b">
					<?php $_smarty_tpl->setupSubTemplate('file:../../presentation/templates/search_box.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false)->render();
?>

					<?php $_smarty_tpl->setupSubTemplate('file:../../presentation/templates/departments_list.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false)->render();
?>

					<?php $_smarty_tpl->setupSubTemplate($_smarty_tpl->tpl_vars['obj']->value->mCategoriesCell, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true)->render();
?>

				</div>
			</div>
		</div>
	</body>
</html><?php }
}
