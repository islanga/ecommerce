<?php /* Smarty version 3.1.28-dev/63, created on 2016-01-05 22:24:27
         compiled from "C:\wamp\www\tshirtshop\presentation\templates\first_page_contents.tpl" */ ?>
<?php
$_valid = $_smarty_tpl->decodeProperties(array (
  'has_nocache_code' => false,
  'version' => '3.1.28-dev/63',
  'unifunc' => 'content_568c348b4eb6c8_60503222',
  'file_dependency' => 
  array (
    'bdf2df2fd730c982eb546abc933bc9f8c857eb4b' => 
    array (
      0 => 'C:\\wamp\\www\\tshirtshop\\presentation\\templates\\first_page_contents.tpl',
      1 => 1452029065,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false);
if ($_valid && !is_callable('content_568c348b4eb6c8_60503222')) {
function content_568c348b4eb6c8_60503222 ($_smarty_tpl) {
?>

<p class="description">
  We hope you have fun developing TShirtShop, the e-commerce store from 
  Beginning PHP and MySQL E-Commerce: From Novice to Professional!
</p>
<p>
  We have the largest collection of t-shirts with postal stamps on Earth!
  Browse our departments and categories to find your favorite!
</p>
<?php }
}
