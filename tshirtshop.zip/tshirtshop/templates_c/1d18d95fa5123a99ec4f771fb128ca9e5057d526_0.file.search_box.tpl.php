<?php /* Smarty version 3.1.28-dev/63, created on 2015-12-20 23:12:42
         compiled from "C:\wamp\www\tshirtshop\presentation\templates\search_box.tpl" */ ?>
<?php
$_valid = $_smarty_tpl->decodeProperties(array (
  'has_nocache_code' => false,
  'version' => '3.1.28-dev/63',
  'unifunc' => 'content_567727db2dc891_76794415',
  'file_dependency' => 
  array (
    '1d18d95fa5123a99ec4f771fb128ca9e5057d526' => 
    array (
      0 => 'C:\\wamp\\www\\tshirtshop\\presentation\\templates\\search_box.tpl',
      1 => 1450647748,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false);
if ($_valid && !is_callable('content_567727db2dc891_76794415')) {
function content_567727db2dc891_76794415 ($_smarty_tpl) {
if (!is_callable('smarty_function_load_presentation_object')) require_once 'C:\\wamp\\www\\tshirtshop\\presentation\\smarty_plugins\\function.load_presentation_object.php';
?>

<?php echo smarty_function_load_presentation_object(array('filename'=>"search_box",'assign'=>"obj"),$_smarty_tpl);?>


<div class="box">
	<p class="box-title">Search the Catalog</p>
	<form class="search_form" method="post" action="<?php echo $_smarty_tpl->tpl_vars['obj']->value->mLinkToSearch;?>
">
		<p>
			<input maxlength="100" id="search_string" name="search_string" value="<?php echo $_smarty_tpl->tpl_vars['obj']->value->mSearchString;?>
" size="19" />
			<input type="submit" value="Go!" /><br />
		</p>
		<p>
			<input type="checkbox" id="all_words" name="all_words" <?php if ($_smarty_tpl->tpl_vars['obj']->value->mAllWords == "on") {?> checked="checked" <?php }?> />Search for all words
		</p>
	</form>
</div>
<?php }
}
