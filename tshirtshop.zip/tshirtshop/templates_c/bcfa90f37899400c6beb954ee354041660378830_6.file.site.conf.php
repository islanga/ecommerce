<?php /* Smarty version 3.1.28-dev/63, created on 2015-11-04 21:50:25
         compiled from "C:\wamp\www\tshirtshop\include\configs\site.conf" */ ?>
<?php
$_valid = $_smarty_tpl->decodeProperties(array (
  'has_nocache_code' => false,
  'version' => '3.1.28-dev/63',
  'unifunc' => 'content_563a6f912a5977_40864340',
  'file_dependency' => 
  array (
    'bcfa90f37899400c6beb954ee354041660378830' => 
    array (
      0 => 'C:\\wamp\\www\\tshirtshop\\include\\configs\\site.conf',
      1 => 1445025573,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false);
if ($_valid && !is_callable('content_563a6f912a5977_40864340')) {
function content_563a6f912a5977_40864340 ($_smarty_tpl) {
Smarty_Internal_Method_ConfigLoad::_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'site_title' => 'TShirtShop: Demo Product Catalog from Beginning PHP and MySQL E-Commerce',
  ),
));
}
}
